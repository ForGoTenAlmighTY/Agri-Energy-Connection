using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Agri_Energy_Connect.Services;
using Agri_Energy_Connect.Models;

namespace Agri_Energy_Connect.Pages.Admin.Products
{

    public class IndexModel : PageModel
    {
        private readonly AppDbContext appContext;

        //Search for date and product type

        [BindProperty(SupportsGet = true)]
        public string Search { get; set; } = "";

        [BindProperty]
        public ProductDetail ProductDetail { get; set; } = new ProductDetail();

        //List of products
        public IList<Product> Products { get; set; }=new List<Product>();

        public IndexModel(AppDbContext appContext)
        {
            this.appContext = appContext;
        }


        public void OnGet(string sortOrder="type_asc")
        {

            //Sorting
            IQueryable<Product> productsQuery = appContext.Product;
            ViewData["TypeSort"] = sortOrder=="type_asc"? "type_desc" : "type_asc";
            ViewData["DateSort"] = sortOrder == "date_asc" ? "date_desc" : "date_asc";

            //Search filter
            if (!string.IsNullOrEmpty(Search))
            {
                productsQuery = productsQuery.Where(p =>
                p.ProductionDate.ToString().Contains(Search)||
                p.Category.Contains(Search)||
                p.Supplier.Contains(Search));
            }
            
            switch (sortOrder)
            {
                case "id_desc":
                    productsQuery = productsQuery.OrderByDescending(p => p.Id);
                    break;
                case "date_desc":
                    productsQuery = productsQuery.OrderByDescending(p => p.ProductionDate);
                    break;
                case "type_asc":
                    productsQuery = productsQuery.OrderBy(p => p.ProductionDate);
                    break;
                case "type_desc":
                    productsQuery = productsQuery.OrderByDescending(p => p.ProductionDate);
                    break;
                default:
                    productsQuery = productsQuery.OrderBy(p => p.ProductionDate);
                    break;

            }

            //Display the list of products fom the query
            Products = productsQuery.ToList();


        }
    }
}
