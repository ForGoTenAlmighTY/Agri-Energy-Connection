using Agri_Energy_Connect.Models;
using Agri_Energy_Connect.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Agri_Energy_Connect.Pages.Admin.Products
{
    public class EditModel : PageModel
    {
        private readonly AppDbContext appDbContext;

        [BindProperty]
        public ProductDetail ProductDetail { get; set; }=new ProductDetail();

        public Product Product { get; set; } = new Product();

        public EditModel(AppDbContext appDbContext) 
        {
            this.appDbContext = appDbContext;
        }
        public void OnGet(int? id)
        {
            if (id == null)
            {
                Response.Redirect("/Admin/Products/Index");
                return;
            }


            var product = appDbContext.Product.Find(id);
            if (product == null)
            {
                Response.Redirect("/Admin/Products/Index");
                return;
            }

            ProductDetail.ProductName=product.ProductName; 
            ProductDetail.ProductDescription=product.ProductDescription;
            ProductDetail.Category = product.Category;
            ProductDetail.ProductionDate=product.ProductionDate;
            ProductDetail.Supplier=product.Supplier;

            Product = product;
        }

        public void OnPost(int? id)
        {
            if (id == null)
            {
                Response.Redirect("/Admin/Products/Index");
                return;
            }

            var product = appDbContext.Product.Find(id);
            if (product == null)
            {
                Response.Redirect("/Admin/Products/Index");
                return;
            }

            Response.Redirect("/Admin/Products/Index");

        }
    }
}
