using Agri_Energy_Connect.Models;
using Agri_Energy_Connect.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Agri_Energy_Connect.Pages.Farmer
{
    public class MyProductsModel : PageModel
    {
        private readonly AppDbContext appContext;

        public string Search { get; set; } = "";

        [BindProperty]
        public ProductDetail ProductDetail { get; set; } = new ProductDetail();

        //List of products
        public IList<Product> Products { get; set; } = new List<Product>();

        public MyProductsModel(AppDbContext appContext)
        {
            this.appContext = appContext;
        }

        public void OnGet()
        {
            Search = User.Identity?.Name!;
            IQueryable<Product> productsQuery = appContext.Product;
            productsQuery= productsQuery.Where(p=> p.Supplier.Contains(Search));
            Products = productsQuery.ToList();
        }
    }
}
