using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Agri_Energy_Connect.Services;
using Agri_Energy_Connect.Models;

namespace Agri_Energy_Connect.Pages.Farmer.Products
{

    public class IndexModel : PageModel
    {
        private readonly AppDbContext appContext;

        public List<Product> Products { get; set; }=new List<Product>();
        public IndexModel(AppDbContext appContext)
        {
            this.appContext = appContext;
        }

        public void OnGet()
        {
            Products= appContext.Product.OrderByDescending(p => p.Id).ToList();
        }
    }
}
