using Agri_Energy_Connect.Models;
using Agri_Energy_Connect.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Agri_Energy_Connect.Pages.Farmer.Products
{
    public class CreateModel : PageModel
    {
        private AppDbContext appDbContext;

        [BindProperty]
        public ProductDetail ProductDetail {  get; set; }= new ProductDetail();

        public CreateModel(AppDbContext appDbContext)
        {
            this.appDbContext=appDbContext;
        }

        public void OnGet()
        {
        }

        public string successMessage = "";
        public string errorMessage = "";
        public void OnPost()
        {
            if (!ModelState.IsValid)
            {
                errorMessage = "Please provide all reuired fields";
                return;
            }

            //Add new product to database
            Product products = new Product()
            {
                ProductName = ProductDetail.ProductName,
                Category = ProductDetail.Category,
                ProductDescription = ProductDetail.ProductDescription ?? "",
                ProductionDate = (DateTime)ProductDetail.ProductionDate!,
                Supplier=User.Identity?.Name!,
            };
            appDbContext.Product.Add(products);
            appDbContext.SaveChanges();

            //Clear form
            ProductDetail.ProductName = "";
            ProductDetail.ProductDescription = "";
            ProductDetail.Category = "";
            ProductDetail.ProductionDate = null;
            ProductDetail.Supplier = "";

            ModelState.Clear();

            successMessage = "Product created successfully";
            Response.Redirect("/Farmer/Products/Index");

        }
    }
}
