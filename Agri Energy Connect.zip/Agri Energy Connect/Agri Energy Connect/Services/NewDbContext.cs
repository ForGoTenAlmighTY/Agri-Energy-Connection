﻿using Agri_Energy_Connect.Models;
using Microsoft.EntityFrameworkCore;

namespace Agri_Energy_Connect.Services
{
    public class NewDbContext: DbContext
    {
        public NewDbContext(DbContextOptions optionsAction) : base(optionsAction) 
        {
            
        }

        
    }
}
