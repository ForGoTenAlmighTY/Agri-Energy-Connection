﻿using System.ComponentModel.DataAnnotations;

namespace Agri_Energy_Connect.Models
{
    public class ProductDetail
    {
        [Required, MaxLength(100)]
        public string ProductName { get; set; } = string.Empty;
        
        public string? ProductDescription { get; set; }

        [Required,MaxLength(100)]
        public string Category { get; set; } = string.Empty;

        public DateTime? ProductionDate { get; set; }
        public string Supplier{get; set;}=string.Empty;
    }
}
