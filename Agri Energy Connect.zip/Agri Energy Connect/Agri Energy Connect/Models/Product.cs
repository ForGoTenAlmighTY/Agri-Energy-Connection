﻿using System.ComponentModel.DataAnnotations;

namespace Agri_Energy_Connect.Models
{
    public class Product
    {
        public int Id { get; set; }
        [MaxLength(100)]
        public string ProductName { get; set; } = string.Empty;
        public string ProductDescription { get; set; } = string.Empty;
        [MaxLength(100)]
        public string Category { get; set; } = string.Empty;

        public DateTime ProductionDate { get; set; }
        [MaxLength(100)]
        public string Supplier { get; set; }=string.Empty;
    }
}
