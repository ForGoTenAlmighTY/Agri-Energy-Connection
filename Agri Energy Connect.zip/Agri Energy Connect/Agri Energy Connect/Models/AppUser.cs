﻿using Microsoft.AspNetCore.Identity;

namespace Agri_Energy_Connect.Models
{
    public class AppUser:IdentityUser
    {
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";

    }
}
